<?php
	include_once("../Model/DeptoDao.class.php");

	class DeptoBO
	{
		function update()
		{
			//pega os dados da tela e guarda em vari�veis auxiliares
			try
			{
				$codigo= 
				  CadDeptoValidation::getCodigo();
				$nome=CadDeptoValidation::getNome();
				
				//cria o componente para manipula��o dos dado na Tabela	
				$depto = 
				  new DeptoDao();
				//chama o m�todo para gravar os dados na tabela Depto
				$depto->update(
				"nome='$nome'",
				"codigo=$codigo");
			}
			catch(Exception $ex)
			{
			
				throw $ex;
			}
		
		}
		public function delete()
		{
			try
			{			
				$codigo= 
				  CadDeptoValidation::getCodigo();
				//cria o componente para manipula��o dos dado na Tabela	
				$func = 
				  new DeptoDao();
				//chama o m�todo para gravar os dados na tabela Funcionario
				$func->delete("
				 codigo=$codigo");
			}
			catch(Exception $ex)
			{
			
				throw $ex;
			}			  
			
		}		
	
		function insert()
		{
			//pega os dados da tela e guarda em vari�veis auxiliares
			
			try
			{
				$codigo= 
				  CadDeptoValidation::getCodigo();
				$nome=CadDeptoValidation::getNome();
				
				//cria o componente para manipula��o dos dado na Tabela	
				$depto = 
				  new DeptoDao();
				//chama o m�todo para gravar os dados na tabela Depto
				$retorno = $depto->insert(
				"codigo,nome",
				"$codigo,'$nome'");
				
				if ($retorno==1)
					return "<h3>Grava&ccedil;&atilde;o com sucesso
						 </h3>";			
				else
					return "<h3>N&atilde;o foi poss�vel fazer a grava&ccedil;&atilde;o, verifique!
						 </h3>";				

			}
			catch(Exception $ex)
			{
			
				throw $ex;
			}
			
		
		}
		function find()
		{
			$codigo= 
			  CadDeptoValidation::getCodigo();

			$depto = 
			  new DeptoDao();

			$row=$depto->find("*", "codigo=$codigo");
			
			if ($row != NULL)
				$_POST["txNome"]=$row[0]["nome"];
			else
				$_POST["txNome"]="";
		}
		function findAll()
		{
			$depto = 
			  new DeptoDao();
			
			$row=$depto->find("*", "");		
			if ($row != NULL)
			{
				$option="";
				//faz um la�o
				for($j = 0; $j < count($row); $j++) 
				{
					$option .= "<option value='".$row[$j]["codigo"]."'>".$row[$j]["nome"]."</option>";
				}
				echo $option;
			}
		}	
	
	}

?>