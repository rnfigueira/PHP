<?php
	include_once("Dao.class.php");
	class DeptoDao extends Dao 
	{
		function __construct()
		{
			//passa o nome da tabela
			//no banco de dados
			parent::__construct("Depto");
		}
		function insert($fields, $values)
		{
			try
			{
				return parent::insert($fields,$values);
			}
			catch (Exception $ex)
			{
				throw $ex;
			}
		}
		function update($fieldsValues, $filter)
		{
			try
			{			
				return parent::update($fieldsValues, $filter);
			}
			catch (Exception $ex)
			{
				throw $ex;
			}
		}
		
		function delete($filter)
		{
			try
			{		
				return parent::delete($filter);
			}
			catch (Exception $ex)
			{
				throw $ex;
			}			
		}
		function find($columns,$filter)
		{

			if (parent::find($columns,$filter) > 0)
				return parent::getRecordSet();
			else
				return NULL;	
		}
		
	}

?>