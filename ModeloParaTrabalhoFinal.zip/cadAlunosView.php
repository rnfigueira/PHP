<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css"> 
			
.style1 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style2 {color: #FF0000}
body {
	margin: 0; /* zerando as margens do body */
	padding: 0; /* zerando os paddings do body */
}
#topo {
	margin: 0; /* zerando as margens do elemento */
	height: 100px; /* definindo altura do elemento */
	background-color: #FFFFFF; /* definindo cor de background */
	width: 100%; /* definindo largura do elemento */
	position: absolute; /* deixando o elemento com uma posi��o absoluta ao corpo da p�gina */
	z-index: 1; /* seto o valor 1 para o z-index, fazendo com que ele fique com prioridades de visualiza��o em rela��o ao outro elemento, que n�o possui este atributo ou pode ter um valor menor. */

}
#menu {
	margin: 0; /* zerando as margens do elemento */
	background-color: #F0F0F0; /* definindo cor de background */
	color:#FFFFFF;
	width: 17%; /* definindo largura do elemento */
	height: 100%; /* definindo altura do elemento */
	left: 0; /* definido 0 pro lado direito do elemento, fazendo com que ele fique colado */
	top: 0px; /* definido 0 pro topo do elemento, fazendo com que ele fique colado */
	position: absolute; /* deixando o elemento com uma posi��o absoluta ao corpo da p�gina */
}
#centro
{
	margin: 0; /* zerando as margens do elemento */
	height: 65%; /* definindo altura do elemento */
	background-color: #FFFFFF;  /* definindo cor de background */
	width: 81%; /* definindo largura do elemento */
	top:25%;
	left:19%;
	position: absolute; /* deixando o elemento com uma posi��o absoluta ao corpo da p�gina */

}
</style>
<title>Sistema Escolar</title>
</head>

<body>
<form action="cadAlunos.php" method="post" >
	<div id="topo"> 
	<table width="100%" border="0">
  <tr>
    <td  width="162"><img src="image/imagem.JPG" width="165px" height="80px"></td>
    <td width="1031" height="70" align="center" valign="middle" bgcolor="#FF3300"><h1> Sistema de Controle de Alunos</h1></td>
  </tr>
</table>
<hr  />
</div>
  <div id="menu">
		<p>&nbsp;</p>
		<p>&nbsp;</p>				
		<p>&nbsp;</p>
		<p>&nbsp;</p>	
		<p>&nbsp;</p>
			
		<p align="center"><a href="cadAlunosView.php" >Cadastro Alunos</a></p>
		<p align="center"><a href="cadNotasView.php" >Cadastro Notas</a></p>
		<p align="center"><a href="consTurmasView.php" >Consulta alunos/Turmas</a></p>
        <p align="center"> <a  href="#" target="mainFrame" onclick="top.window.close();">Fecha Sistema</a></p>

		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>

  
  </div>
  <div id="centro">
  	<h3 class="style1"><u>Cadastramento de Alunos </u>	</h3>
  	<p class="style1">
    <?php
	
	?>
    &nbsp;</p>
<p>C&oacute;digo:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input name="txCodigo" type="text" id="txCodigo">
			<span class="style2">* </span>
		</p>
		<p>Nome Aluno:&nbsp; <input name="txNome" type="text" id="txNome" size="50">
			<span class="style2">* </span></p>
		<p>
			Turma:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input name="txTurma" type="text" id="txTurma">
			<span class="style2">* </span></p>
		<p>
			<input type="submit" name="btOperacao" id="btOperacao" value="Gravar" >
			<input type="submit" name="btOperacao" id="btOperacao" value="Alterar" />
			<input type="submit" name="btOperacao" id="btOperacao" value="Excluir" />
			<input type="submit" name="btOperacao" id="btOperacao" value="Consultar" /> 
			<input type="submit" name="btOperacao" id="btOperacao" value="Limpar">
		</p>
	<p>
    <?php
	
    
    ?>
    &nbsp;</p>
	<p>&nbsp;</p>
	<p>&nbsp;</p>

  </div>
  </form>
</body>
</html>
